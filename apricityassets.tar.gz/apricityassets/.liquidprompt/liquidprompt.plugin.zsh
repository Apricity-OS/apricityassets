source ${0%/*}/liquidprompt
